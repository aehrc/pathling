"""
Pathling Python API
"""
from ._version import __version__
