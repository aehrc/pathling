#
# Auto generated from POM project version.
# Please do not modify.
#
__version__="5.0.0"
