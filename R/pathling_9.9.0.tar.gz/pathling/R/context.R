#  Copyright © 2018-2026 Commonwealth Scientific and Industrial Research
#  Organisation (CSIRO) ABN 41 687 119 230.
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.


#' Terminology cache storage type
#'
#' The type of storage to use for the terminology cache.
#'
#' The following values are supported:
#' \itemize{
#'   \item \code{MEMORY} - Use an in-memory cache
#'   \item \code{DISK} - Use a disk-based cache
#' }
#'
#' @export
StorageType <- list(
  MEMORY = "memory",
  DISK = "disk"
)

#' Create or retrieve the Pathling context
#'
#' Creates a Pathling context with the given configuration options.
#'
#' If no Spark session is provided and there is not one already present in this process, a new
#' one will be created.
#'
#' If a SparkSession is not provided, and one is already running within the current process, it
#' will be reused.
#'
#' It is assumed that the Pathling library API JAR is already on the classpath. If you are running
#' your own cluster, make sure it is on the list of packages.
#'
#' @param spark A pre-configured SparkSession instance, use this if you need to control the way
#'   that the session is set up
#' @param max_nesting_level Controls the maximum depth of nested element data that is encoded
#'   upon import. This affects certain elements within FHIR resources that contain recursive
#'   references, e.g., QuestionnaireResponse.item.
#' @param enable_extensions Enables support for FHIR extensions
#' @param enabled_open_types The list of types that are encoded within open types, such as
#'   extensions.
#' @param enable_terminology Enables the use of terminology functions
#' @param terminology_server_url The endpoint of a FHIR terminology service (R4) that the server
#'   can use to resolve terminology queries.
#' @param terminology_verbose_request_logging Setting this option to TRUE will enable additional
#'   logging of the details of requests to the terminology service.
#' @param terminology_socket_timeout The maximum period (in milliseconds) that the server should
#'   wait for incoming data from the HTTP service
#' @param max_connections_total The maximum total number of connections for the client
#' @param max_connections_per_route The maximum number of connections per route for the client
#' @param terminology_retry_enabled Controls whether terminology requests that fail for possibly
#'   transient reasons should be retried
#' @param terminology_retry_count The number of times to retry failed terminology requests
#' @param enable_cache Set this to FALSE to disable caching of terminology requests
#' @param cache_max_entries Sets the maximum number of entries that will be held in memory
#' @param cache_storage_type The type of storage to use for the terminology cache
#' @param cache_storage_path The path on disk to use for the cache
#' @param cache_default_expiry The default expiry time for cache entries (in seconds)
#' @param cache_override_expiry If provided, this value overrides the expiry time provided by the
#'   terminology server
#' @param token_endpoint An OAuth2 token endpoint for use with the client credentials grant
#' @param enable_auth Enables authentication of requests to the terminology server
#' @param client_id A client ID for use with the client credentials grant
#' @param client_secret A client secret for use with the client credentials grant
#' @param scope A scope value for use with the client credentials grant
#' @param token_expiry_tolerance The minimum number of seconds that a token should have before
#'   expiry when deciding whether to send it with a terminology request
#' @param accept_language The default value of the Accept-Language HTTP header passed to the
#'   terminology server. In local mode this selects the preferred display and designation language.
#' @param terminology_mode The terminology evaluation backend, either "server" (the default) or
#'   "local" (evaluating against a local terminology store with no network access)
#' @param terminology_storage_path The location of the local terminology store, required when
#'   terminology_mode is "local"
#' @param default_snomed_edition The SNOMED CT module identifier used to disambiguate an unversioned
#'   SNOMED reference when the local store holds multiple editions
#' @param expansion_cache_size The maximum number of value set expansions cached per executor in
#'   local mode
#' @param dialect_aliases Additional dialect tags recognised in local mode when a display or
#'   designation is requested in a particular language, given as a named character vector or list
#'   mapping a language tag to the identifier of the SNOMED CT language reference set that serves it
#'   (for example c("en-NZ" = "271000210107")). An entry for a tag that is already recognised
#'   replaces the built-in mapping for it. At most ten aliases can be configured from R
#' @param explain_queries Setting this option to TRUE will enable additional logging relating
#'   to the query plan used to execute queries
#' @param max_unbound_traversal_depth Maximum depth for self-referencing structure traversals
#'   in repeat operations. Controls how deeply nested hierarchical data can be flattened
#'   during projection.
#'
#' @return A Pathling context instance initialized with the specified configuration
#'
#' @importFrom sparklyr j_invoke_static j_invoke
#'
#' @family context lifecycle functions
#'
#' @export
#'
#' @examples \dontrun{
#' # Create PathlingContext for an existing Spark connecton.
#' pc <- pathling_connect(spark = sc)
#'
#' # Create PathlingContext with a new Spark connection.
#' pc <- pathling_connect()
#' spark <- pathling_spark(pc)
#' }
pathling_connect <- function(
  spark = NULL,
  max_nesting_level = 3,
  enable_extensions = FALSE,
  enabled_open_types = c(
    "boolean", "code", "date", "dateTime", "decimal", "integer",
    "string", "Coding", "CodeableConcept", "Address", "Identifier", "Reference"
  ),
  enable_terminology = TRUE,
  terminology_server_url = "https://tx.ontoserver.csiro.au/fhir",
  terminology_verbose_request_logging = FALSE,
  terminology_socket_timeout = 60000,
  max_connections_total = 32,
  max_connections_per_route = 16,
  terminology_retry_enabled = TRUE,
  terminology_retry_count = 2,
  enable_cache = TRUE,
  cache_max_entries = 200000,
  cache_storage_type = StorageType$MEMORY,
  cache_storage_path = NULL,
  cache_default_expiry = 600,
  cache_override_expiry = NULL,
  token_endpoint = NULL,
  enable_auth = FALSE,
  client_id = NULL,
  client_secret = NULL,
  scope = NULL,
  token_expiry_tolerance = 120,
  accept_language = NULL,
  terminology_mode = "server",
  terminology_storage_path = NULL,
  default_snomed_edition = NULL,
  expansion_cache_size = 100,
  dialect_aliases = NULL,
  explain_queries = FALSE,
  max_unbound_traversal_depth = 10
) {
  if (!terminology_mode %in% c("server", "local")) {
    stop("terminology_mode must be 'server' or 'local'")
  }
  if (terminology_mode == "local" && is.null(terminology_storage_path)) {
    stop("terminology_storage_path is required when terminology_mode is 'local'")
  }
  spark_info <- pathling_spark_info()


  new_spark_connection <- function() {
    sparklyr::spark_connect(master = "local[*]", config = list("sparklyr.shell.conf" = c(
      "spark.sql.mapKeyDedupPolicy=LAST_WIN",
      "spark.sql.extensions=io.delta.sql.DeltaSparkSessionExtension",
      "spark.sql.catalog.spark_catalog=org.apache.spark.sql.delta.catalog.DeltaCatalog"
    )), version = spark_info$spark_version)
  }

  spark <- if (!is.null(spark)) {
    spark
  } else {
    new_spark_connection()
  }

  encoders_config <- spark %>%
    j_invoke_static(
      "au.csiro.pathling.config.EncodingConfiguration", "builder"
    ) %>%
    j_invoke("maxNestingLevel", as.integer(max_nesting_level)) %>%
    j_invoke("enableExtensions", as.logical(enable_extensions)) %>%
    j_invoke("openTypes", spark %>% j_to_set(enabled_open_types)) %>%
    j_invoke("build")

  client_config <- j_invoke_static(
    spark, "au.csiro.pathling.config.HttpClientConfiguration", "builder"
  ) %>%
    j_invoke("socketTimeout", as.integer(terminology_socket_timeout)) %>%
    j_invoke("maxConnectionsTotal", as.integer(max_connections_total)) %>%
    j_invoke("maxConnectionsPerRoute", as.integer(max_connections_per_route)) %>%
    j_invoke("retryEnabled", as.logical(terminology_retry_enabled)) %>%
    j_invoke("retryCount", as.integer(terminology_retry_count)) %>%
    j_invoke("build")

  cache_storage_type_enum <- j_invoke_static(
    spark, "au.csiro.pathling.config.HttpClientCachingStorageType", "fromCode",
    as.character(cache_storage_type)
  )

  cache_config <- j_invoke_static(
    spark, "au.csiro.pathling.config.HttpClientCachingConfiguration", "builder"
  ) %>%
    j_invoke("enabled", as.logical(enable_cache)) %>%
    j_invoke("maxEntries", as.integer(cache_max_entries)) %>%
    j_invoke("storageType", cache_storage_type_enum) %>%
    j_invoke("storagePath", cache_storage_path) %>%
    j_invoke("defaultExpiry", as.integer(cache_default_expiry)) %>%
    j_invoke("overrideExpiry", cache_override_expiry) %>%
    j_invoke("build")

  auth_config <- j_invoke_static(
    spark, "au.csiro.pathling.config.TerminologyAuthConfiguration", "builder"
  ) %>%
    j_invoke("enabled", as.logical(enable_auth)) %>%
    j_invoke("tokenEndpoint", token_endpoint) %>%
    j_invoke("clientId", client_id) %>%
    j_invoke("clientSecret", client_secret) %>%
    j_invoke("scope", scope) %>%
    j_invoke("tokenExpiryTolerance", as.integer(token_expiry_tolerance)) %>%
    j_invoke("build")

  mode_enum <- j_invoke_static(
    spark, "au.csiro.pathling.config.TerminologyMode", "valueOf",
    toupper(terminology_mode)
  )

  terminology_config_builder <- j_invoke_static(
    spark, "au.csiro.pathling.config.TerminologyConfiguration", "builder"
  ) %>%
    j_invoke("enabled", as.logical(enable_terminology)) %>%
    j_invoke("serverUrl", terminology_server_url) %>%
    j_invoke("verboseLogging", as.logical(terminology_verbose_request_logging)) %>%
    j_invoke("client", client_config) %>%
    j_invoke("cache", cache_config) %>%
    j_invoke("authentication", auth_config) %>%
    j_invoke("acceptLanguage", accept_language) %>%
    j_invoke("mode", mode_enum)

  if (!is.null(terminology_storage_path)) {
    local_config <- j_invoke_static(
      spark, "au.csiro.pathling.config.LocalTerminologyConfiguration", "builder"
    ) %>%
      j_invoke("storagePath", terminology_storage_path) %>%
      j_invoke("defaultSnomedEdition", default_snomed_edition) %>%
      j_invoke("expansionCacheSize", as.integer(expansion_cache_size))
    if (length(dialect_aliases) > 0) {
      local_config <- j_invoke(
        local_config, "dialectAliases", java_map_of(spark, dialect_aliases)
      )
    }
    local_config <- local_config %>%
      j_invoke("build")
    terminology_config_builder <- terminology_config_builder %>%
      j_invoke("local", local_config)
  }

  terminology_config <- terminology_config_builder %>%
    j_invoke("build")

  query_config <- j_invoke_static(
    spark, "au.csiro.pathling.config.QueryConfiguration", "builder"
  ) %>%
    j_invoke("explainQueries", as.logical(explain_queries)) %>%
    j_invoke("maxUnboundTraversalDepth", as.integer(max_unbound_traversal_depth)) %>%
    j_invoke("build")

  j_invoke_static(
    spark, "au.csiro.pathling.library.PathlingContext", "builder",
    sparklyr::spark_session(spark)
  ) %>%
    j_invoke("encodingConfiguration", encoders_config) %>%
    j_invoke("terminologyConfiguration", terminology_config) %>%
    j_invoke("queryConfiguration", query_config) %>%
    j_invoke("build")
}

#' Build a Java map from a named vector or list
#'
#' Converts a named character vector or list into a \code{java.util.Map} for passing to a Java
#' method. The map is built by a single call to \code{Map.of}, because sparklyr can neither pass an
#' R map to a Java method (an R environment arrives as a Scala map, which does not match a
#' \code{java.util.Map} parameter) nor build a Java map up entry by entry (a Java method returning
#' void or null desynchronises sparklyr's protocol and brings the session down).
#'
#' \code{Map.of} is overloaded for up to ten entries, which is therefore the most this can carry.
#'
#' @param spark The Spark connection.
#' @param entries A named character vector or list.
#'
#' @return A jobj referring to a \code{java.util.Map}.
#'
#' @noRd
java_map_of <- function(spark, entries) {
  if (length(entries) > 10) {
    stop(
      "At most 10 dialect aliases can be configured from R. Configure the remainder through the ",
      "Java or Python API, or reach a dialect by its private-use extension tag."
    )
  }
  # Interleave the tags and identifiers into the key, value, key, value order Map.of takes.
  tags <- names(entries)
  interleaved <- as.list(as.vector(rbind(
    tags, vapply(tags, function(tag) as.character(entries[[tag]]), character(1))
  )))
  do.call(
    j_invoke_static,
    c(list(spark, "java.util.Map", "of"), interleaved)
  )
}

#' Get the Spark session
#'
#' Returns the Spark connection associated with a Pathling context.
#'
#' @param pc The PathlingContext object.
#'
#' @return The Spark connection associated with this Pathling context.
#'
#' @family context lifecycle functions
#'
#' @export
pathling_spark <- function(pc) {
  sparklyr::spark_connection(pc)
}

#' Disconnect from the Spark session
#'
#' Disconnects the Spark connection associated with a Pathling context.
#'
#' @param pc The PathlingContext object.
#'
#' @return No return value, called for side effects only.
#'
#' @family context lifecycle functions
#'
#' @export
pathling_disconnect <- function(pc) {
  sparklyr::spark_disconnect(pathling_spark(pc))
  invisible(NULL)
}

#' Disconnect all Spark connections
#'
#' @return No return value, called for side effects only.
#'
#' @family context lifecycle functions
#'
#' @export
pathling_disconnect_all <- function() {
  sparklyr::spark_disconnect_all()
  invisible(NULL)
}

#' Convert a FHIR search expression to a Spark Column
#'
#' Converts a FHIR search query string into a Spark Column representing a boolean filter condition.
#' The returned Column can be used with sparklyr DataFrame operations such as \code{sdf_filter} to
#' filter resources matching the search criteria.
#'
#' @param pc The PathlingContext object.
#' @param resource_type A string containing the FHIR resource type code (e.g., "Patient",
#'   "Observation").
#' @param search_expression A FHIR search query string in URL query format (e.g.,
#'   "gender=male&birthdate=ge1990-01-01"). An empty string matches all resources.
#'
#' @return A Spark Column object (\code{spark_jobj}) representing the boolean filter condition.
#'
#' @importFrom sparklyr j_invoke
#'
#' @family context functions
#'
#' @export
#'
#' @examples \dontrun{
#' pc <- pathling_connect()
#' data_source <- pc %>% pathling_read_ndjson(pathling_examples("ndjson"))
#' patients <- data_source %>% ds_read("Patient")
#'
#' # Filter patients by gender.
#' filtered <- patients %>%
#'   pathling_filter(pc, "Patient", "gender=male", type = "search")
#'
#' # Multiple search parameters (AND).
#' filtered <- patients %>%
#'   pathling_filter(pc, "Patient", "gender=male&active=true", type = "search")
#'
#' pathling_disconnect(pc)
#' }
pathling_search_to_column <- function(pc, resource_type, search_expression) {
  j_invoke(pc, "searchToColumn", as.character(resource_type), as.character(search_expression))
}

#' Convert a FHIRPath expression to a Spark Column
#'
#' Converts a FHIRPath expression into a Spark Column that can be used in DataFrame operations
#' such as filtering and selection. Boolean expressions can be used for filtering, while other
#' expressions can be used for value extraction.
#'
#' The expression should evaluate to a single value per resource row.
#'
#' @param pc The PathlingContext object.
#' @param resource_type A string containing the FHIR resource type code (e.g., "Patient",
#'   "Observation").
#' @param fhirpath_expression A FHIRPath expression to evaluate (e.g., "gender = 'male'",
#'   "name.given.first()").
#'
#' @return A Spark Column object (\code{spark_jobj}) representing the evaluated expression.
#'
#' @importFrom sparklyr j_invoke
#'
#' @family context functions
#'
#' @export
#'
#' @examples \dontrun{
#' pc <- pathling_connect()
#' data_source <- pc %>% pathling_read_ndjson(pathling_examples("ndjson"))
#' patients <- data_source %>% ds_read("Patient")
#'
#' # Filter patients using a boolean FHIRPath expression.
#' filtered <- patients %>%
#'   pathling_filter(pc, "Patient", "gender = 'male'")
#'
#' # Value expression for selection.
#' name_col <- pathling_fhirpath_to_column(pc, "Patient", "name.given.first()")
#'
#' pathling_disconnect(pc)
#' }
pathling_fhirpath_to_column <- function(pc, resource_type, fhirpath_expression) {
  j_invoke(pc, "fhirPathToColumn", as.character(resource_type), as.character(fhirpath_expression))
}

#' Filter a DataFrame using a FHIRPath or search expression
#'
#' Filters a \code{tbl_spark} using either a FHIRPath boolean expression or a FHIR search query
#' string, returning a \code{tbl_spark} containing only the matching rows. The DataFrame must be the
#' first argument to enable piping with \code{\%>\%}.
#'
#' @param df A \code{tbl_spark} containing FHIR resource data.
#' @param pc The PathlingContext object.
#' @param resource_type A string containing the FHIR resource type code (e.g., "Patient",
#'   "Observation").
#' @param expression The filter expression. For \code{type = "fhirpath"}, a FHIRPath boolean
#'   expression (e.g., "gender = 'male'"). For \code{type = "search"}, a FHIR search query string
#'   (e.g., "gender=male&birthdate=ge1990-01-01").
#' @param type The type of expression: \code{"fhirpath"} (default) or \code{"search"}.
#'
#' @return A \code{tbl_spark} containing only the rows matching the expression.
#'
#' @importFrom sparklyr j_invoke spark_dataframe sdf_register
#'
#' @family context functions
#'
#' @export
#'
#' @examples \dontrun{
#' pc <- pathling_connect()
#' data_source <- pc %>% pathling_read_ndjson(pathling_examples("ndjson"))
#' patients <- data_source %>% ds_read("Patient")
#'
#' # Filter using a FHIRPath expression.
#' male_patients <- patients %>%
#'   pathling_filter(pc, "Patient", "gender = 'male'")
#'
#' # Filter using a FHIR search expression.
#' male_patients <- patients %>%
#'   pathling_filter(pc, "Patient", "gender=male", type = "search")
#'
#' pathling_disconnect(pc)
#' }
pathling_filter <- function(df, pc, resource_type, expression, type = "fhirpath") {
  col <- if (type == "search") {
    pathling_search_to_column(pc, resource_type, expression)
  } else {
    pathling_fhirpath_to_column(pc, resource_type, expression)
  }
  sparklyr::spark_dataframe(df) %>%
    j_invoke("filter", col) %>%
    sparklyr::sdf_register()
}

#' Add a FHIRPath-derived column to a DataFrame
#'
#' Evaluates a FHIRPath expression and adds the result as a named column to a \code{tbl_spark},
#' returning the augmented \code{tbl_spark}. The DataFrame must be the first argument to enable
#' piping with \code{\%>\%}. Multiple calls can be chained to add several columns.
#'
#' @param df A \code{tbl_spark} containing FHIR resource data.
#' @param pc The PathlingContext object.
#' @param resource_type A string containing the FHIR resource type code (e.g., "Patient",
#'   "Observation").
#' @param expression A FHIRPath expression to evaluate (e.g., "name.given.first()").
#' @param column The name of the new column to add.
#'
#' @return A \code{tbl_spark} with the new column added.
#'
#' @importFrom sparklyr j_invoke spark_dataframe sdf_register
#'
#' @family context functions
#'
#' @export
#'
#' @examples \dontrun{
#' pc <- pathling_connect()
#' data_source <- pc %>% pathling_read_ndjson(pathling_examples("ndjson"))
#' patients <- data_source %>% ds_read("Patient")
#'
#' # Add a single column.
#' result <- patients %>%
#'   pathling_with_column(pc, "Patient", "name.given.first()", column = "given_name")
#'
#' # Chain multiple columns.
#' result <- patients %>%
#'   pathling_with_column(pc, "Patient", "name.given.first()", column = "given_name") %>%
#'   pathling_with_column(pc, "Patient", "gender", column = "gender_value") %>%
#'   dplyr::select(id, given_name, gender_value)
#'
#' pathling_disconnect(pc)
#' }
pathling_with_column <- function(df, pc, resource_type, expression, column) {
  col <- pathling_fhirpath_to_column(pc, resource_type, expression)
  sparklyr::spark_dataframe(df) %>%
    j_invoke("withColumn", as.character(column), col) %>%
    sparklyr::sdf_register()
}

#' Evaluate a FHIRPath expression against a single FHIR resource
#'
#' Evaluates a FHIRPath expression against a single FHIR resource provided as a JSON string and
#' returns materialised typed results. The resource is encoded into a one-row Spark Dataset
#' internally, and the existing FHIRPath engine is used to evaluate the expression.
#'
#' @param pc The PathlingContext object.
#' @param resource_type A string containing the FHIR resource type code (e.g., "Patient",
#'   "Observation").
#' @param resource_json A string containing the FHIR resource as JSON.
#' @param fhirpath_expression A FHIRPath expression to evaluate (e.g., "name.family",
#'   "gender = 'male'").
#' @param context_expression An optional context expression string. If provided, the main
#'   expression is evaluated once for each result of the context expression. Defaults to NULL.
#' @param variables An optional named list of variables available via \code{\%variable} syntax.
#'   Defaults to NULL.
#'
#' @return A list with two elements:
#'   \describe{
#'     \item{\code{results}}{A list of lists, each containing \code{type} (character) and
#'       \code{value} (the materialised R value or NULL).}
#'     \item{\code{expectedReturnType}}{A character string indicating the inferred return type.}
#'   }
#'
#' @importFrom sparklyr invoke j_invoke j_invoke_new spark_connection
#'
#' @family context functions
#'
#' @export
#'
#' @examples \dontrun{
#' pc <- pathling_connect()
#' patient_json <- '{"resourceType": "Patient", "id": "example", "gender": "male"}'
#' result <- pathling_evaluate_fhirpath(pc, "Patient", patient_json, "gender")
#' for (entry in result$results) {
#'   cat(entry$type, ": ", entry$value, "\n")
#' }
#' pathling_disconnect(pc)
#' }
pathling_evaluate_fhirpath <- function(pc, resource_type, resource_json,
                                       fhirpath_expression,
                                       context_expression = NULL,
                                       variables = NULL) {
  # Convert R named list to a Java HashMap if variables are provided.
  java_variables <- NULL
  if (!is.null(variables)) {
    sc <- spark_connection(pc)
    java_variables <- j_invoke_new(sc, "java.util.HashMap")
    for (name in names(variables)) {
      invoke(java_variables, "put", name, variables[[name]])
    }
  }

  jresult <- invoke(
    pc, "evaluateFhirPath",
    as.character(resource_type),
    as.character(resource_json),
    as.character(fhirpath_expression),
    context_expression,
    java_variables
  )

  # Convert Java SingleInstanceEvaluationResult to an R list.
  jtyped_values <- invoke(jresult, "getResults")
  size <- jtyped_values %>% invoke("size")
  results <- if (size > 0L) {
    lapply(seq_len(size), function(i) {
      jtv <- jtyped_values %>% invoke("get", as.integer(i - 1))
      list(
        type = jtv %>% invoke("getType"),
        value = jtv %>% invoke("getValue")
      )
    })
  } else {
    list()
  }

  list(
    results = results,
    expectedReturnType = invoke(jresult, "getExpectedReturnType")
  )
}
